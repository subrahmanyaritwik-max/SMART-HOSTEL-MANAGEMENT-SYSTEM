import React from 'react';
import './NoticeItem.css';

function NoticeItem({ notice }) {
  return (
    <div className="notice-item">
      <span className="notice-date">{notice.date}</span>
      <h3 className="notice-title">{notice.title}</h3>
      <p className="notice-content">{notice.content}</p>
    </div>
  );
}

export default NoticeItem;
