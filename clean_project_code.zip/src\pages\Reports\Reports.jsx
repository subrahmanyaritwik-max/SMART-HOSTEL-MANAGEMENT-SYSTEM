import React from 'react';
import ReportCard from '../../components/ReportCard/ReportCard';
import './Reports.css';

function Reports({ students, complaints, setPage }) {
  const totalRooms = 50; // Static value as per requirement
  const totalStudents = students.length;
  const occupiedRooms = totalStudents; // Assuming 1 student per room for simplicity
  const vacantRooms = totalRooms - occupiedRooms;
  const totalComplaints = complaints.length;

  return (
    <div className="reports-container">
      <div className="page-header">
        <button className="back-btn" onClick={() => setPage('admin')}>← Back to Dashboard</button>
        <h2 className="page-title">Hostel Reports</h2>
        <p className="page-subtitle">Statistics and current status of the hostel</p>
      </div>

      <div className="reports-grid">
        <ReportCard 
          title="Total Rooms" 
          value={totalRooms} 
          icon="🏢" 
          colorClass="primary" 
        />
        <ReportCard 
          title="Occupied Rooms" 
          value={occupiedRooms} 
          icon="🔴" 
          colorClass="danger" 
        />
        <ReportCard 
          title="Vacant Rooms" 
          value={vacantRooms} 
          icon="🟢" 
          colorClass="success" 
        />
        <ReportCard 
          title="Total Students" 
          value={totalStudents} 
          icon="👥" 
          colorClass="info" 
        />
        <ReportCard 
          title="Total Complaints" 
          value={totalComplaints} 
          icon="📝" 
          colorClass="warning" 
        />
      </div>
    </div>
  );
}

export default Reports;
