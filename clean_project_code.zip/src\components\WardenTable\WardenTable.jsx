import React from 'react';
import './WardenTable.css';

// WardenTable component receives wardens array as props — Component Reusability
function WardenTable({ wardens }) {
  return (
    <div className="warden-table-wrapper">
      <table className="warden-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Phone Number</th>
            <th>Block</th>
            <th>Shift</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {/* Rendering table rows using map() — Lists and Keys */}
          {wardens.map((warden) => (
            <tr key={warden.id}>
              <td className="warden-name">
                <span className="warden-avatar">👨‍💼</span>
                {warden.name}
              </td>
              <td>{warden.phone}</td>
              <td>
                <span className="block-badge">{warden.block}</span>
              </td>
              <td>
                <span className={`shift-badge ${warden.shift === 'Day' ? 'shift-day' : 'shift-night'}`}>
                  {warden.shift === 'Day' ? '☀️' : '🌙'} {warden.shift}
                </span>
              </td>
              <td>
                {/* Simple Call button — Event Handling */}
                <a href={`tel:${warden.phone}`} className="call-btn">
                  📞 Call
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default WardenTable;
