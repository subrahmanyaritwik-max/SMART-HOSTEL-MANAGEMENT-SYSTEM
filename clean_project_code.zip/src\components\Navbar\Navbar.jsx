import React from 'react';
import './Navbar.css';

// Navbar component receives 'currentPage' and 'setPage' as props from App.jsx
function Navbar({ currentPage, setPage }) {
  // Array of navigation items — uses Lists and Keys concept
  const navItems = [
    { id: 1, label: '🏠 Home', page: 'home' },
    { id: 2, label: '🛏️ Rooms', page: 'rooms' },
    { id: 3, label: '📝 Complaints', page: 'complaints' },
    { id: 4, label: '🍽️ Menu', page: 'menu' },
    { id: 5, label: '👨‍💼 Warden', page: 'warden' },
    { id: 6, label: '📢 Notices', page: 'notices' },
    { id: 7, label: '🔐 Admin', page: 'admin' },
  ];

  return (
    <nav className="navbar">
      <div className="navbar-brand" onClick={() => setPage('home')}>
        {/* Logo and title */}
        <span className="navbar-logo">✨</span>
        <h2>Hostel Management</h2>
      </div>

      <ul className="navbar-links">
        {/* Rendering nav items using map() — Lists and Keys */}
        {navItems.map((item) => (
          <li key={item.id}>
            <button
              className={currentPage === item.page ? 'active' : ''}
              onClick={() => setPage(item.page)}
            >
              {item.label}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export default Navbar;
