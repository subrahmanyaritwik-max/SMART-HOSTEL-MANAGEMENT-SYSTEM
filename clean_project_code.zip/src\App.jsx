import React, { useState } from 'react';
import Navbar from './components/Navbar/Navbar';
import Home from './pages/Home/Home';
import Rooms from './pages/Rooms/Rooms';
import Complaints from './pages/Complaints/Complaints';
import Menu from './pages/Menu/Menu';
import AdminLogin from './pages/AdminLogin/AdminLogin';
import Dashboard from './pages/Dashboard/Dashboard';
import AddStudent from './pages/AddStudent/AddStudent';
import Reports from './pages/Reports/Reports';
import Warden from './pages/Warden/Warden';
import Notices from './pages/Notices/Notices';
import './App.css';

// App is the main (root) functional component
function App() {
  // useState to manage the current page being displayed
  const [currentPage, setCurrentPage] = useState('home');

  // useState to track if admin is logged in
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);

  // useState to store student list (shared between pages)
  const [students, setStudents] = useState([
    { id: 1, name: 'Rithvik', rollNumber: 'CS2301', phone: '9876543210', room: '101' },
    { id: 2, name: 'Rahul', rollNumber: 'CS2302', phone: '9123456789', room: '103' },
    { id: 3, name: 'Amit', rollNumber: 'CS2303', phone: '9988776655', room: '105' },
    { id: 4, name: 'Kiran', rollNumber: 'CS2304', phone: '9876512345', room: '106' },
    { id: 5, name: 'Suresh', rollNumber: 'CS2305', phone: '9001122334', room: '108' },
    { id: 6, name: 'Varun', rollNumber: 'CS2306', phone: '9112233445', room: '110' },
  ]);

  // useState to store complaints list (shared between pages)
  const [complaints, setComplaints] = useState([
    { id: 1, title: 'No Internet', description: 'Wi-Fi is not working on the 1st floor.' },
    { id: 2, title: 'Water Leak', description: 'Tap is leaking in room 103.' },
  ]);

  // useState to store mess menu items (shared between pages)
  const [menuItems, setMenuItems] = useState([
    { id: 1, day: 'Monday', breakfast: 'Idli & Chutney', lunch: 'Rice, Dal, Curry', dinner: 'Chapati & Paneer Curry' },
    { id: 2, day: 'Tuesday', breakfast: 'Dosa & Sambar', lunch: 'Veg Biryani', dinner: 'Rice & Chicken Curry' },
    { id: 3, day: 'Wednesday', breakfast: 'Upma', lunch: 'Rice, Sambar, Fry', dinner: 'Noodles & Manchuria' },
    { id: 4, day: 'Thursday', breakfast: 'Poori & Potato Curry', lunch: 'Fried Rice', dinner: 'Chapati & Kurma' },
    { id: 5, day: 'Friday', breakfast: 'Pongal', lunch: 'Rice & Egg Curry', dinner: 'Paratha & Curry' },
    { id: 6, day: 'Saturday', breakfast: 'Vada & Coconut Chutney', lunch: 'Veg Meals Special', dinner: 'Jeera Rice & Paneer' },
    { id: 7, day: 'Sunday', breakfast: 'Masala Dosa', lunch: 'Chicken Biryani', dinner: 'Chapati & Veg Curry' },
  ]);

  // Handler for admin logout
  const handleLogout = () => {
    setIsAdminLoggedIn(false);
    setCurrentPage('home');
  };

  // Conditional Rendering: Function to return the correct page component
  const renderPage = () => {
    if (currentPage === 'home') {
      return <Home setPage={setCurrentPage} />;
    } else if (currentPage === 'rooms') {
      return <Rooms students={students} />;
    } else if (currentPage === 'complaints') {
      return (
        <Complaints
          complaints={complaints}
          setComplaints={setComplaints}
        />
      );
    } else if (currentPage === 'menu') {
      return <Menu menuItems={menuItems} />;
    } else if (currentPage === 'warden') {
      return <Warden />;
    } else if (currentPage === 'notices') {
      return <Notices />;
    } else if (currentPage === 'admin') {
      // If admin is logged in, show dashboard; otherwise show login page
      if (isAdminLoggedIn) {
        return (
          <Dashboard
            setPage={setCurrentPage}
            handleLogout={handleLogout}
          />
        );
      } else {
        return (
          <AdminLogin
            setIsAdminLoggedIn={setIsAdminLoggedIn}
            setPage={setCurrentPage}
          />
        );
      }
    } else if (currentPage === 'addStudent') {
      return (
        <AddStudent
          students={students}
          setStudents={setStudents}
          setPage={setCurrentPage}
        />
      );
    } else if (currentPage === 'manageMenu') {
      return (
        <Menu
          menuItems={menuItems}
          setMenuItems={setMenuItems}
          isAdmin={true}
          setPage={setCurrentPage}
        />
      );
    } else if (currentPage === 'adminRooms') {
      return <Rooms students={students} setPage={setCurrentPage} isAdmin={true} />;
    } else if (currentPage === 'adminComplaints') {
      return (
        <Complaints
          complaints={complaints}
          setComplaints={setComplaints}
          setPage={setCurrentPage}
          isAdmin={true}
        />
      );
    } else if (currentPage === 'reports') {
      return (
        <Reports
          students={students}
          complaints={complaints}
          setPage={setCurrentPage}
        />
      );
    }
  };

  return (
    <div className="app-container">
      {/* Passing state and state-updater as props to Navbar */}
      <Navbar currentPage={currentPage} setPage={setCurrentPage} />

      {/* Rendering the main content based on state */}
      <div className="main-content">
        <div className="page-wrapper" key={currentPage}>
          {renderPage()}
        </div>
      </div>
    </div>
  );
}

export default App;
