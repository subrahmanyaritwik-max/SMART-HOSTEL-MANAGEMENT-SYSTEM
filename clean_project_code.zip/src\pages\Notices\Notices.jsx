import React from 'react';
import NoticeItem from '../../components/NoticeItem/NoticeItem';
import './Notices.css';

function Notices() {
  // Static array of notices
  const noticesList = [
    {
      id: 1,
      date: '10-Oct-2023',
      title: 'Hostel Fees Due',
      content: 'Please pay your hostel fees for the upcoming semester by 25th October.'
    },
    {
      id: 2,
      date: '12-Oct-2023',
      title: 'Water Supply Interruption',
      content: 'There will be no water supply on 15th October from 10 AM to 2 PM due to maintenance.'
    },
    {
      id: 3,
      date: '14-Oct-2023',
      title: 'Diwali Celebration',
      content: 'Join us for Diwali celebrations in the common hall on 24th October at 6 PM.'
    }
  ];

  return (
    <div className="notices-container">
      <h2>Notice Board</h2>
      <p>Important announcements for all residents:</p>
      
      <div className="notices-list">
        {noticesList.map(notice => (
          <NoticeItem key={notice.id} notice={notice} />
        ))}
      </div>
    </div>
  );
}

export default Notices;
