import React, { useState } from 'react';
import StudentCard from '../../components/StudentCard/StudentCard';
import './AddStudent.css';

function AddStudent({ students, setStudents, setPage }) {
  const [name, setName] = useState('');
  const [rollNumber, setRollNumber] = useState('');
  const [phone, setPhone] = useState('');
  const [room, setRoom] = useState('');

  const handleAddStudent = (e) => {
    e.preventDefault();
    if (!name || !rollNumber || !phone || !room) {
      alert('Please fill out all fields');
      return;
    }

    const newStudent = {
      id: Date.now(),
      name,
      rollNumber,
      phone,
      room,
    };

    setStudents([...students, newStudent]);
    
    setName('');
    setRollNumber('');
    setPhone('');
    setRoom('');
  };

  return (
    <div className="add-student-container">
      <div className="page-header">
        <button className="back-btn" onClick={() => setPage('admin')}>← Back to Dashboard</button>
        <h2 className="page-title">Manage Students</h2>
        <p className="page-subtitle">Add new students to the hostel</p>
      </div>

      <form onSubmit={handleAddStudent} className="student-form glass-card">
        <h3>Add New Student</h3>
        <div className="form-grid">
          <div className="form-group">
            <label>Student Name:</label>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. John Doe" />
          </div>
          <div className="form-group">
            <label>Roll Number:</label>
            <input type="text" value={rollNumber} onChange={(e) => setRollNumber(e.target.value)} placeholder="e.g. CS2307" />
          </div>
          <div className="form-group">
            <label>Phone Number:</label>
            <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="e.g. 9876543210" />
          </div>
          <div className="form-group">
            <label>Room Number:</label>
            <input type="text" value={room} onChange={(e) => setRoom(e.target.value)} placeholder="e.g. 111" />
          </div>
        </div>
        <button type="submit" className="btn-primary w-100 mt-1">➕ Add Student</button>
      </form>

      <div className="students-list-section">
        <h3>Current Students ({students.length})</h3>
        <div className="students-grid">
          {students.map((student) => (
            <StudentCard key={student.id} student={student} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default AddStudent;
