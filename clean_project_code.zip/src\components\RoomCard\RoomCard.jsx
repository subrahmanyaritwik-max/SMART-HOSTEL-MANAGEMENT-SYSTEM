import React from 'react';
import './RoomCard.css';

// RoomCard component receives 'room' details and 'onClick' handler as props
function RoomCard({ room, onClick }) {
  // Using conditional rendering to change the style and text based on occupancy
  return (
    <div
      className={`room-card ${room.isOccupied ? 'occupied' : 'vacant'}`}
      onClick={onClick}
    >
      <div className="room-icon">
        {room.isOccupied ? '🔴' : '🟢'}
      </div>
      <h3>Room {room.number}</h3>
      <p className="room-status">
        {room.isOccupied ? 'Occupied' : 'Vacant'}
      </p>
      {/* Conditional rendering — show student name or availability */}
      {room.isOccupied ? (
        <p className="room-student">👤 {room.studentName}</p>
      ) : (
        <p className="room-available">Available</p>
      )}
      <span className="room-tap-hint">Tap for details →</span>
    </div>
  );
}

export default RoomCard;
