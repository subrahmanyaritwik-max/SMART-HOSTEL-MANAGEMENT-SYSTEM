import React from 'react';
import './StudentCard.css';

function StudentCard({ student }) {
  return (
    <div className="student-card glass-card">
      <div className="student-avatar">👤</div>
      <div className="student-info">
        <h3>{student.name}</h3>
        <p><strong>Roll No:</strong> {student.rollNumber}</p>
        <p><strong>Phone:</strong> {student.phone}</p>
        <p><strong>Room:</strong> {student.room}</p>
      </div>
    </div>
  );
}

export default StudentCard;
