import React from 'react';
import './ComplaintItem.css';

// ComplaintItem receives complaint object and handleDelete function as props
function ComplaintItem({ complaint, handleDelete }) {
  return (
    <div className="complaint-item">
      <div className="complaint-info">
        <h4>⚠️ {complaint.title}</h4>
        <p>{complaint.description}</p>
      </div>
      {/* Event handling — delete button calls handleDelete with complaint ID */}
      <button onClick={() => handleDelete(complaint.id)} className="delete-btn">
        🗑️ Delete
      </button>
    </div>
  );
}

export default ComplaintItem;
