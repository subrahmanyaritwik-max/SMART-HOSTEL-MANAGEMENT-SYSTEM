import React from 'react';
import './ReportCard.css';

function ReportCard({ title, value, icon, colorClass }) {
  return (
    <div className={`report-card glass-card ${colorClass}`}>
      <div className="report-icon">{icon}</div>
      <div className="report-content">
        <h3>{value}</h3>
        <p>{title}</p>
      </div>
    </div>
  );
}

export default ReportCard;
